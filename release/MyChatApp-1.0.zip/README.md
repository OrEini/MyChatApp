# MyChatApp

Simple chat app

How to install:
* Install the attached .apk file on Android mobile device.

How to use:
* At the first startup of the app, you need to select a username.
* You need to choose Room ID that you want to join.
* The dummy chat will start after you send the first message.(every time that you send message you will receive after 2 sec the same response)

Assumptions:
* My focus on the Frontend, the UI and UX.
* The dummy chat works without backend (Due to the shortness of time).




